package androidstudio.tutorials;


import processing.core.PApplet;
public class Sketch extends PApplet {
    Client cl;
    String whatServerSaid;
    String[] param = new String[3];
    int coordX=0;
    int coordY=0;


    public void settings() {
        size(1000, 1000);
    }

    public void setup() {
        //cl = new Client(this, "169.254.123.61", 5204);
        cl = new Client(this, "192.168.59.163", 5204);
        //cl = new Client(this, "192.168.1.78", 5204);
    }
    public void draw() {
        background(0);
        if (cl.available() > 0) {
            whatServerSaid = cl.readString();
            println("message from server: "+whatServerSaid);
            param = split(whatServerSaid, ",");
            if(param[0].equals("coordserver")){
                coordX=parseInt(param[1]);
                coordY=parseInt(param[2]);
            }
        }
        ellipse(coordX,coordY,50,50);
    }
    public void mousePressed(){
        cl.write("coordclient,"+mouseX+","+mouseY);
        println("x:"+mouseX+ " y:"+mouseY);
        coordX=mouseX;
        coordY=mouseY;
    }
}

